
			function awal(){
				Interval = setInterval("hitung()",1);
			}

			function hitung(){
				a =parseInt(document.getElementById("harga").value);
				b =parseInt(document.getElementById("ukuran").value);
				c =parseInt(document.getElementById("type").value);
				d =parseInt(document.getElementById("motif").value);
				total = (a + b + c + d);
				document.getElementById("total").value=total;

			}

			/*function tes(){
				if(total < 100){
					window.alert('Persentase Kurang dari 100%');
				}else if(total > 100){
					window.alert('Persentase Lebih dari 100%');					
				}else if(total == 100){
					window.open('../controller/proses_ban.php');	
					}
			}*/

	$(function () {
        $('#total').onkeyup(function () {
            if ($(this).val() != 100 ) {
                $('.lanjut').prop('disabled', true);
            } else {
                $('.lanjut').prop('disabled', false);
            }
        });
    });



			function berhenti(){
				clearInteval(Interval);
			}


   