<?php
	include "views/header.php";
	include "views/navbar.php";
?>
<div class="container">
    <div class="row">
        <div class="box">
        	<h3 class="text-center">Record Data</h3>
			<table class="table table-bordered table-striped">
            <thead>
				<tr>
					<th>Merk</th>
					<th>Harga</th>
					<th>Model</th>
					<th>Type</th>
					<th>Warna Leher</th>
                </tr>
            </thead>
				<tbody>
					<?php
						include "config/koneksi.php";
						$query = mysqli_query($konek,"select * from data_kn") or die (mysqli_error());
						if(mysqli_num_rows($query) == 0)
						{
							echo "<b>Data Not Avaible</b>";
						}
						else
						{
							while($result = mysqli_fetch_array($query)):
					?>			
					<tr>
						<td><?php echo $result['merk']; ?></td>
						<td><?php echo $result['harga']; ?></td>
						<td><?php echo $result['model']; ?></td>
						<td><?php echo $result['type']; ?></td>
						<td><?php echo $result['warna']; ?></td>
					</tr>
					<?php
						endwhile;
						}
					?>
                </tbody>
			</table><br>
			<h3 class="text-center">Nilai Atribut</h3>
			<table class="table table-bordered table-striped">
            <thead>
				<tr>
					<th>Harga</th>
					<th>Model</th>
					<th>Type</th>
					<th>Warna Leher</th>
                </tr>
            </thead>
				<tbody>
					<?php
						include "config/koneksi.php";
						$query = mysqli_query($konek,"select * from atribut_kn") or die (mysqli_error());
						if(mysqli_num_rows($query) == 0)
						{
							echo "<b>Data Not Avaible</b>";
						}
						else
						{
							while($result = mysqli_fetch_array($query)):
					?>			
					<tr>
						<td><?php echo $result['harga']; ?></td>
						<td><?php echo $result['model']; ?></td>
						<td><?php echo $result['type']; ?></td>
						<td><?php echo $result['warna']; ?></td>
					</tr>
					<?php
						endwhile;
						}
					?>
                </tbody>
			</table><br>
			<h3 class="text-center">Normalisasi Data</h3>
			<table class="table table-bordered table-striped">
            <thead>
				<tr>
					<th>Merk</th>
					<th>Harga</th>
					<th>Model</th>
					<th>Type</th>
					<th>Warna Leher</th>
                </tr>
            </thead>
				<tbody>
					<?php
						include "config/koneksi.php";
						$query = mysqli_query($konek,"select * from nor_kn") or die (mysqli_error());
						if(mysqli_num_rows($query) == 0)
						{
							echo "<b>Data Not Avaible</b>";
						}
						else
						{
							while($result = mysqli_fetch_array($query)):
					?>			
					<tr>
						<td><?php echo $result['merk']; ?></td>
						<td><?php echo $result['harga']; ?></td>
						<td><?php echo $result['model']; ?></td>
						<td><?php echo $result['type']; ?></td>
						<td><?php echo $result['warna']; ?></td>
					</tr>
					<?php
						endwhile;
						}
					?>
                </tbody>
			</table><br>
			<h3 class="text-center">Rekomendasi Sistem</h3>
			<table class="table table-bordered table-striped">
            <thead>
				<tr>
					<th>Merk</th>
					<th>Point</th>
                </tr>
            </thead>
				<tbody>
					<?php
						include "config/koneksi.php";
						$query = mysqli_query($konek,"select * from ranking_kn order by point desc") or die (mysqli_error());
						if(mysqli_num_rows($query) == 0)
						{
							echo "<b>Data Not Avaible</b>";
						}
						else
						{
							while($result = mysqli_fetch_array($query)):
					?>			
					<tr>
						<td><?php echo $result['merk']; ?></td>
						<td><?php echo $result['point']; ?></td>
					</tr>
					<?php
						endwhile;
						}
					?>
                </tbody>
			</table><br>
		</div>
	</div>
</div>
<?php
	include "views/footer.php";
?>
