	<footer>
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <p>Copyright &copy; <a href="Mothaistyle.com">MoThai Style</a> 2017<br>
						<small><a href="http://stmik.ipem.ac.id">STMIK Insan Pembangunan Bitung</a> | Sistem Informasi 5 D | <a href="https://id.wikipedia.org/wiki/Sistem_pendukung_keputusan">Decision Support System</a></small>
					</p>
                </div>
            </div>
        </div>
    </footer>
	<script src="assets/js/jquery.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
    <script>
		$('.carousel').carousel({
			interval: 5000 //changes the speed
		})
    </script>
</body>
</html>
