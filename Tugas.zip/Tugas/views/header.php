<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<title>MoThai Style</title>
	
	<link rel="icon" type="image/icon" href="assets/img/icon.ico">
	
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/business-casual.css" rel="stylesheet">
	<link href="assets/css/modal.css" rel="stylesheet">
	<script src="assets/js/atribut_ban.js"></script>
	<script src="assets/js/jquery.min.js"></script>
	
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="logo1">
		<img class="logo1" src="assets/img/logo1.png" >
	</div>
	<div class="logo2">
		<img class="logo2" src="assets/img/logo2.png" >
	</div>
    <div class="brand">MoThai Style</div>
    <div class="address-bar">Temanmu memilih spare part thailook terbaik.</div>
	