    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- navbar-brand  -->
                <a class="navbar-brand" href="index.php">Mothai Style</a>
            </div>
            <!-- Navbar-Button -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Dashboard</a>
                    </li>
					<li>
                        <a href="sparepart.php">Spare Part</a>
                    </li>
					<li>
                        <a href="about.php">Tentang</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>